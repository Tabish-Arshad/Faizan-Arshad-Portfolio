import { useState } from 'react';
import { Plus, Search, Edit2, Trash2, ExternalLink, Github, Star } from 'lucide-react';
import { Project } from '../App';

interface ProjectManagementProps {
  onEditProject: (project: Project) => void;
  onNewProject: () => void;
}

export function ProjectManagement({ onEditProject, onNewProject }: ProjectManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const projects: Project[] = [
    {
      id: '1',
      title: 'SAP Custom Module Builder',
      description: 'A comprehensive tool for generating custom function modules in SAP with automated documentation and testing capabilities.',
      technologies: ['SAP ABAP', 'TypeScript', 'React', 'Node.js'],
      imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop',
      demoUrl: 'https://example.com/demo',
      githubUrl: 'https://github.com/username/sap-module-builder',
      featured: true,
      completedAt: '2025-11-15',
    },
    {
      id: '2',
      title: 'ERP Data Migration Tool',
      description: 'Enterprise-grade data migration utility for seamless transfer between different ERP systems with validation and rollback features.',
      technologies: ['Python', 'SQL', 'SAP', 'Oracle'],
      imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop',
      demoUrl: 'https://example.com/demo',
      githubUrl: 'https://github.com/username/erp-migration',
      featured: true,
      completedAt: '2025-10-20',
    },
    {
      id: '3',
      title: 'ALV Report Generator',
      description: 'Automated ALV grid report generator with dynamic field selection, custom layouts, and export functionality.',
      technologies: ['SAP ABAP', 'ALV', 'OOP'],
      imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop',
      demoUrl: 'https://example.com/demo',
      githubUrl: 'https://github.com/username/alv-generator',
      featured: false,
      completedAt: '2025-09-10',
    },
    {
      id: '4',
      title: 'Integration Hub Dashboard',
      description: 'Real-time monitoring dashboard for ERP system integrations with performance metrics and error tracking.',
      technologies: ['React', 'Node.js', 'REST API', 'WebSocket'],
      imageUrl: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=800&h=600&fit=crop',
      demoUrl: 'https://example.com/demo',
      githubUrl: 'https://github.com/username/integration-hub',
      featured: false,
      completedAt: '2025-08-25',
    },
    {
      id: '5',
      title: 'SAP Transport Manager',
      description: 'Simplified transport management system for SAP with automated conflict detection and deployment scheduling.',
      technologies: ['SAP ABAP', 'Node.js', 'Express'],
      imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&h=600&fit=crop',
      demoUrl: 'https://example.com/demo',
      githubUrl: 'https://github.com/username/transport-manager',
      featured: false,
      completedAt: '2025-07-12',
    },
  ];

  const filteredProjects = projects.filter((project) =>
    project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    project.technologies.some((tech) =>
      tech.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Projects</h1>
          <p className="text-gray-600">Manage your portfolio projects and showcases</p>
        </div>
        <button
          onClick={onNewProject}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          New Project
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-lg shadow border border-gray-200 p-6 mb-6">
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredProjects.map((project) => (
          <div
            key={project.id}
            className="bg-white rounded-lg shadow border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div
              className="h-48 bg-cover bg-center"
              style={{ backgroundImage: `url(${project.imageUrl})` }}
            >
              {project.featured && (
                <div className="flex items-center gap-1 bg-yellow-500 text-white px-3 py-1 rounded-br-lg inline-flex">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-sm">Featured</span>
                </div>
              )}
            </div>

            <div className="p-6">
              <h3 className="text-xl mb-2">{project.title}</h3>
              <p className="text-gray-600 mb-4">{project.description}</p>

              <div className="flex flex-wrap gap-2 mb-4">
                {project.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded"
                  >
                    {tech}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <span>Completed: {project.completedAt}</span>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => onEditProject(project)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
                <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                  <ExternalLink className="w-4 h-4" />
                </button>
                <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                  <Github className="w-4 h-4" />
                </button>
                <button className="px-4 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredProjects.length === 0 && (
        <div className="bg-white rounded-lg shadow border border-gray-200 p-12 text-center">
          <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl text-gray-600 mb-2">No projects found</h3>
          <p className="text-gray-500">Try adjusting your search criteria</p>
        </div>
      )}
    </div>
  );
}