import { useState } from 'react';
import { Plus, Search, Edit2, Trash2, Eye, Calendar, Clock } from 'lucide-react';
import { BlogPost } from '../App';

interface BlogManagementProps {
  onEditBlog: (blog: BlogPost) => void;
  onNewBlog: () => void;
}

export function BlogManagement({ onEditBlog, onNewBlog }: BlogManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'published' | 'draft'>('all');

  const blogPosts: BlogPost[] = [
    {
      id: '1',
      title: 'Understanding SAP ABAP Development Best Practices',
      slug: 'sap-abap-best-practices',
      excerpt: 'A comprehensive guide to writing clean and maintainable ABAP code in SAP development.',
      content: '',
      category: 'ERP Development',
      tags: ['SAP', 'ABAP', 'Best Practices'],
      published: true,
      publishedAt: '2025-12-02',
      views: 1243,
      readTime: '8 min',
    },
    {
      id: '2',
      title: 'Integrating ERP Systems with Modern Web Technologies',
      slug: 'erp-web-integration',
      excerpt: 'Learn how to bridge traditional ERP systems with modern web frameworks and APIs.',
      content: '',
      category: 'Integration',
      tags: ['ERP', 'Web Dev', 'APIs'],
      published: true,
      publishedAt: '2025-11-28',
      views: 892,
      readTime: '10 min',
    },
    {
      id: '3',
      title: 'Custom Function Modules in SAP: A Complete Guide',
      slug: 'sap-function-modules-guide',
      excerpt: 'Everything you need to know about creating and managing custom function modules in SAP.',
      content: '',
      category: 'SAP Development',
      tags: ['SAP', 'Function Modules', 'Tutorial'],
      published: true,
      publishedAt: '2025-11-20',
      views: 654,
      readTime: '12 min',
    },
    {
      id: '4',
      title: 'Optimizing Performance in Large ERP Implementations',
      slug: 'erp-performance-optimization',
      excerpt: 'Strategies and techniques for improving performance in enterprise-scale ERP systems.',
      content: '',
      category: 'Performance',
      tags: ['ERP', 'Optimization', 'Performance'],
      published: false,
      publishedAt: '2025-11-15',
      views: 423,
      readTime: '15 min',
    },
    {
      id: '5',
      title: 'Building Custom Reports in SAP with ALV',
      slug: 'sap-alv-reports',
      excerpt: 'Master the art of creating professional reports using ALV in SAP ABAP.',
      content: '',
      category: 'SAP Development',
      tags: ['SAP', 'ALV', 'Reports'],
      published: true,
      publishedAt: '2025-11-10',
      views: 789,
      readTime: '9 min',
    },
    {
      id: '6',
      title: 'Error Handling Best Practices in ERP Development',
      slug: 'erp-error-handling',
      excerpt: 'Implement robust error handling mechanisms in your ERP applications.',
      content: '',
      category: 'Best Practices',
      tags: ['ERP', 'Error Handling', 'Development'],
      published: false,
      publishedAt: '2025-11-05',
      views: 234,
      readTime: '7 min',
    },
  ];

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus =
      filterStatus === 'all' ||
      (filterStatus === 'published' && post.published) ||
      (filterStatus === 'draft' && !post.published);
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Blog Posts</h1>
          <p className="text-gray-600">Manage your blog content and publications</p>
        </div>
        <button
          onClick={onNewBlog}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          New Post
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow border border-gray-200 p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search blog posts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-4 py-2 rounded-lg ${
                filterStatus === 'all'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterStatus('published')}
              className={`px-4 py-2 rounded-lg ${
                filterStatus === 'published'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Published
            </button>
            <button
              onClick={() => setFilterStatus('draft')}
              className={`px-4 py-2 rounded-lg ${
                filterStatus === 'draft'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Drafts
            </button>
          </div>
        </div>
      </div>

      {/* Blog Posts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredPosts.map((post) => (
          <div
            key={post.id}
            className="bg-white rounded-lg shadow border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">
                      {post.category}
                    </span>
                    <span
                      className={`text-xs px-2 py-1 rounded ${
                        post.published
                          ? 'bg-green-100 text-green-700'
                          : 'bg-yellow-100 text-yellow-700'
                      }`}
                    >
                      {post.published ? 'Published' : 'Draft'}
                    </span>
                  </div>
                  <h3 className="text-xl mb-2">{post.title}</h3>
                </div>
              </div>

              <p className="text-gray-600 mb-4">{post.excerpt}</p>

              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map((tag) => (
                  <span key={tag} className="text-xs px-2 py-1 bg-blue-50 text-blue-700 rounded">
                    #{tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{post.publishedAt}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{post.views} views</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{post.readTime}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => onEditBlog(post)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
                <button className="px-4 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredPosts.length === 0 && (
        <div className="bg-white rounded-lg shadow border border-gray-200 p-12 text-center">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl text-gray-600 mb-2">No blog posts found</h3>
          <p className="text-gray-500">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  );
}
