import { ExternalLink, Github, Star } from 'lucide-react';
import { motion } from 'framer-motion';

export function ProjectsPage() {
  const projects = [
    {
      id: '1',
      title: 'SAP Custom Module Builder',
      description: 'A comprehensive tool for generating custom function modules in SAP with automated documentation and testing capabilities. Streamlines the development process and ensures consistency across projects.',
      technologies: ['SAP ABAP', 'TypeScript', 'React', 'Node.js'],
      imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop',
      demoUrl: '#',
      githubUrl: '#',
      featured: true,
    },
    {
      id: '2',
      title: 'ERP Data Migration Tool',
      description: 'Enterprise-grade data migration utility for seamless transfer between different ERP systems with validation and rollback features. Supports multiple data formats and provides detailed migration reports.',
      technologies: ['Python', 'SQL', 'SAP', 'Oracle'],
      imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop',
      demoUrl: '#',
      githubUrl: '#',
      featured: true,
    },
    {
      id: '3',
      title: 'ALV Report Generator',
      description: 'Automated ALV grid report generator with dynamic field selection, custom layouts, and export functionality. Reduces report development time by up to 70%.',
      technologies: ['SAP ABAP', 'ALV', 'OOP'],
      imageUrl: 'https://images.unsplash.com/photo-1603351130949-476794ec3dff?w=800&h=600&fit=crop',
      demoUrl: '#',
      githubUrl: '#',
      featured: false,
    },
    {
      id: '4',
      title: 'Integration Hub Dashboard',
      description: 'Real-time monitoring dashboard for ERP system integrations with performance metrics and error tracking. Provides instant visibility into system health and integration status.',
      technologies: ['React', 'Node.js', 'REST API', 'WebSocket'],
      imageUrl: 'https://images.unsplash.com/photo-1646153114001-495dfb56506d?w=800&h=600&fit=crop',
      demoUrl: '#',
      githubUrl: '#',
      featured: false,
    },
    {
      id: '5',
      title: 'SAP Transport Manager',
      description: 'Simplified transport management system for SAP with automated conflict detection and deployment scheduling. Improves deployment success rate and reduces manual errors.',
      technologies: ['SAP ABAP', 'Node.js', 'Express'],
      imageUrl: 'https://images.unsplash.com/photo-1719400471588-575b23e27bd7?w=800&h=600&fit=crop',
      demoUrl: '#',
      githubUrl: '#',
      featured: false,
    },
    {
      id: '6',
      title: 'ERP Performance Monitor',
      description: 'Advanced monitoring solution for tracking ERP system performance, identifying bottlenecks, and providing optimization recommendations.',
      technologies: ['Python', 'SAP', 'Grafana', 'PostgreSQL'],
      imageUrl: 'https://images.unsplash.com/photo-1644088379091-d574269d422f?w=800&h=600&fit=crop',
      demoUrl: '#',
      githubUrl: '#',
      featured: false,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="py-12 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl mb-4 bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Projects</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            A showcase of my work in ERP development, SAP solutions, and enterprise integrations
          </p>
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {projects.map((project) => (
            <motion.div
              key={project.id}
              variants={itemVariants}
              whileHover={{ y: -10, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.15)" }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200 group"
            >
              <div className="relative overflow-hidden h-48">
                <motion.img
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.6 }}
                  src={project.imageUrl}
                  alt={project.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                {project.featured && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.3 }}
                    className="absolute top-4 left-4 flex items-center gap-1 bg-yellow-400 text-gray-900 px-3 py-1 rounded-full shadow-lg"
                  >
                    <Star className="w-4 h-4 fill-current" />
                    <span className="text-sm">Featured</span>
                  </motion.div>
                )}
              </div>

              <div className="p-6">
                <h3 className="text-xl mb-3 group-hover:text-emerald-600 transition-colors">{project.title}</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">{project.description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="text-xs px-3 py-1 bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-700 rounded-full border border-emerald-200"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex gap-2 pt-4 border-t border-gray-200">
                  <motion.a
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    href={project.demoUrl}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-lg hover:shadow-lg transition-shadow"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Demo
                  </motion.a>
                  <motion.a
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    href={project.githubUrl}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
                  >
                    <Github className="w-4 h-4" />
                    Code
                  </motion.a>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}