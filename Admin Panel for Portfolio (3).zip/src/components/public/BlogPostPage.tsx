import { ArrowLeft, Calendar, Clock, Eye, Share2, Tag, BookmarkPlus, ThumbsUp, MessageCircle, TrendingUp } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { motion } from 'motion/react';

interface BlogPostPageProps {
  postId: string;
  onBack: () => void;
}

export function BlogPostPage({ postId, onBack }: BlogPostPageProps) {
  // Mock data - in real app, fetch based on postId
  const post = {
    id: postId,
    title: 'Understanding SAP ABAP Development Best Practices',
    category: 'SAP Development',
    tags: ['SAP', 'ABAP', 'Best Practices', 'Clean Code', 'Performance'],
    date: '2025-12-02',
    readTime: '8 min',
    views: 1243,
    likes: 89,
    comments: 24,
    author: {
      name: 'John Doe',
      title: 'Functional ERP Developer',
      bio: '8+ years of experience in SAP ABAP development',
    },
    image: 'https://images.unsplash.com/photo-1603351130949-476794ec3dff?w=1200&h=600&fit=crop',
    content: String.raw`
SAP ABAP development requires a disciplined approach to ensure maintainability and performance. In this comprehensive guide, we'll explore the essential best practices that every ABAP developer should follow.

## Introduction

Writing clean, maintainable ABAP code is crucial for long-term success in enterprise SAP implementations. This guide will walk you through proven best practices that will elevate your development skills.

## Naming Conventions

Proper naming conventions are crucial for code readability and maintenance. Always use descriptive names that clearly indicate the purpose of variables, methods, and classes.

### Key Points:
- Use meaningful prefixes (Z or Y for custom objects)
- Follow SAP naming standards
- Be consistent across your codebase
- Document complex logic

## Code Example

Here's an example of a well-structured ABAP function module:

` + '```abap' + `
FUNCTION Z_CALCULATE_DISCOUNT.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_AMOUNT) TYPE WRBTR
*"     VALUE(IV_CUSTOMER_TYPE) TYPE CHAR1
*"  EXPORTING
*"     VALUE(EV_DISCOUNT) TYPE WRBTR
*"----------------------------------------------------------------------

  DATA: lv_discount_rate TYPE p DECIMALS 2.

  CASE iv_customer_type.
    WHEN 'A'.
      lv_discount_rate = '0.15'.
    WHEN 'B'.
      lv_discount_rate = '0.10'.
    WHEN OTHERS.
      lv_discount_rate = '0.05'.
  ENDCASE.

  ev_discount = iv_amount * lv_discount_rate.

ENDFUNCTION.
` + '```' + `

## Performance Optimization

When working with large datasets, always consider these optimization techniques:

1. **Use internal tables with appropriate table types** (STANDARD, SORTED, HASHED)
2. **Implement proper indexing strategies**
3. **Avoid nested SELECT statements inside loops**
4. **Use field symbols for better performance**

Here's a Python example for comparison of data processing:

` + '```python' + `
def calculate_discount(amount, customer_type):
    """
    Calculate discount based on customer type.
    
    Args:
        amount (float): The base amount
        customer_type (str): Customer classification (A, B, or C)
    
    Returns:
        float: Calculated discount amount
    """
    discount_rates = {
        'A': 0.15,
        'B': 0.10,
        'default': 0.05
    }
    
    rate = discount_rates.get(customer_type, discount_rates['default'])
    return amount * rate

# Usage example
discount = calculate_discount(1000, 'A')
print(f"Discount: ${'$'}{discount}")
` + '```' + `

## Database Operations

Efficient database operations are critical in SAP ABAP:

` + '```sql' + `
-- Optimized SELECT statement
SELECT werks, matnr, menge
  FROM marc
  INTO TABLE @DATA(lt_marc)
  WHERE werks IN @s_werks
    AND matnr IN @s_matnr
  ORDER BY werks, matnr.

-- Avoid this pattern
SELECT * FROM marc
  INTO TABLE lt_marc.
` + '```' + `

## Modularization

Break down complex logic into smaller, reusable components. This makes testing easier and improves code maintainability.

### Benefits of Modularization:
- Easier testing and debugging
- Better code reusability
- Improved readability
- Simplified maintenance

## Error Handling

Always implement proper error handling using exception classes:

` + '```javascript' + `
// Modern error handling in JavaScript
async function fetchERPData(endpoint) {
  try {
    const response = await fetch(endpoint, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer YOUR_TOKEN'
      }
    });
    
    if (!response.ok) {
      throw new Error(\`HTTP error! status: ${'$'}{response.status}\`);
    }
    
    const data = await response.json();
    console.log('Data fetched successfully:', data);
    return data;
    
  } catch (error) {
    console.error('Error fetching ERP data:', error);
    // Implement retry logic or fallback
    throw error;
  }
}

// Usage
fetchERPData('/api/sap/materials')
  .then(data => processData(data))
  .catch(error => handleError(error));
` + '```' + `

## Modern Integration Approach

When integrating SAP with modern systems, consider using TypeScript for type safety:

` + '```typescript' + `
interface SAPMaterial {
  matnr: string;
  maktx: string;
  meins: string;
  werks: string;
}

class SAPIntegration {
  private apiUrl: string;
  
  constructor(apiUrl: string) {
    this.apiUrl = apiUrl;
  }
  
  async getMaterials(plant: string): Promise<SAPMaterial[]> {
    const response = await fetch(\`${'$'}{this.apiUrl}/materials?plant=${'$'}{plant}\`);
    const data = await response.json();
    return data as SAPMaterial[];
  }
}

// Usage
const sap = new SAPIntegration('https://api.example.com/sap');
const materials = await sap.getMaterials('1000');
` + '```' + `

## Conclusion

Following these best practices will help you write cleaner, more maintainable ABAP code. Remember that good code is not just about functionality—it's about creating solutions that others can understand and maintain.

### Key Takeaways:
✓ Always follow naming conventions
✓ Optimize for performance from the start
✓ Modularize your code
✓ Implement proper error handling
✓ Document your code thoroughly

By implementing these practices consistently, you'll become a more effective ABAP developer and contribute to better enterprise solutions.
    `,
  };

  const relatedPosts = [
    {
      id: '2',
      title: 'Advanced ABAP OOP Patterns',
      category: 'SAP Development',
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=300&fit=crop',
      readTime: '12 min',
    },
    {
      id: '3',
      title: 'SAP Performance Tuning Guide',
      category: 'Performance',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
      readTime: '15 min',
    },
    {
      id: '4',
      title: 'Modern SAP Integration Techniques',
      category: 'Integration',
      image: 'https://images.unsplash.com/photo-1646153114001-495dfb56506d?w=400&h=300&fit=crop',
      readTime: '10 min',
    },
  ];

  // Parse content with code blocks
  const renderContent = () => {
    const parts = post.content.split(/```(\w+)?\n([\s\S]*?)```/);
    
    return parts.map((part, index) => {
      if (index % 3 === 0) {
        // Regular text - split by headers and lists
        return part.split('\n').map((line, i) => {
          if (line.startsWith('## ')) {
            return (
              <h2 key={`${index}-${i}`} className="text-3xl mt-12 mb-6 bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                {line.substring(3)}
              </h2>
            );
          } else if (line.startsWith('### ')) {
            return (
              <h3 key={`${index}-${i}`} className="text-2xl mt-8 mb-4 text-gray-900">
                {line.substring(4)}
              </h3>
            );
          } else if (line.startsWith('# ')) {
            return (
              <h1 key={`${index}-${i}`} className="text-4xl mt-10 mb-6 text-gray-900">
                {line.substring(2)}
              </h1>
            );
          } else if (line.match(/^\d+\./)) {
            return <li key={`${index}-${i}`} className="ml-6 mb-2 text-gray-700 leading-relaxed">{line.substring(line.indexOf('.') + 1)}</li>;
          } else if (line.startsWith('- ') || line.startsWith('* ')) {
            return <li key={`${index}-${i}`} className="ml-6 mb-2 text-gray-700 leading-relaxed">{line.substring(2)}</li>;
          } else if (line.startsWith('✓ ')) {
            return (
              <div key={`${index}-${i}`} className="flex items-start gap-2 mb-2">
                <span className="text-emerald-500 mt-1">✓</span>
                <span className="text-gray-700">{line.substring(2)}</span>
              </div>
            );
          } else if (line.trim()) {
            return <p key={`${index}-${i}`} className="mb-4 text-gray-700 leading-relaxed text-lg">{line}</p>;
          }
          return null;
        });
      } else if (index % 3 === 2) {
        const language = parts[index - 1] || 'javascript';
        return (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="my-8 rounded-xl overflow-hidden shadow-2xl border-2 border-gray-200"
          >
            <div className="bg-gradient-to-r from-gray-800 to-gray-900 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>
                <span className="text-gray-400 text-sm ml-3">{language}</span>
              </div>
              <button className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-700 rounded hover:bg-gray-600 transition-colors">
                Copy
              </button>
            </div>
            <SyntaxHighlighter
              language={language}
              style={vscDarkPlus}
              customStyle={{
                margin: 0,
                borderRadius: 0,
                fontSize: '0.9rem',
                padding: '1.5rem',
              }}
              showLineNumbers={true}
            >
              {part}
            </SyntaxHighlighter>
          </motion.div>
        );
      }
      return null;
    });
  };

  return (
    <div className="py-12 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          whileHover={{ x: -5 }}
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Blog
        </motion.button>

        {/* Article Header */}
        <motion.article
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200"
        >
          <div className="relative h-96 overflow-hidden">
            <motion.img
              initial={{ scale: 1.2 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.8 }}
              src={post.image}
              alt={post.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
            <div className="absolute bottom-8 left-8 right-8">
              <span className="px-4 py-1.5 bg-emerald-500 text-white rounded-full text-sm shadow-lg inline-block mb-4">
                {post.category}
              </span>
              <h1 className="text-4xl md:text-5xl text-white mb-4">{post.title}</h1>
            </div>
          </div>

          <div className="p-8 md:p-12">
            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-6 pb-8 mb-8 border-b border-gray-200">
              <div className="flex items-center gap-4">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center text-white text-xl shadow-lg"
                >
                  {post.author.name.split(' ').map(n => n[0]).join('')}
                </motion.div>
                <div>
                  <p className="text-gray-900">{post.author.name}</p>
                  <p className="text-sm text-gray-600">{post.author.title}</p>
                </div>
              </div>
              
              <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 ml-auto">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{post.readTime} read</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{post.views} views</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 mb-8">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                <ThumbsUp className="w-4 h-4" />
                <span>{post.likes}</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{post.comments}</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                <BookmarkPlus className="w-4 h-4" />
                Save
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors ml-auto"
              >
                <Share2 className="w-4 h-4" />
                Share
              </motion.button>
            </div>

            {/* Content */}
            <div className="prose prose-lg max-w-none">
              {renderContent()}
            </div>

            {/* Tags */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="mt-12 pt-8 border-t border-gray-200"
            >
              <div className="flex items-center gap-3 flex-wrap">
                <Tag className="w-5 h-5 text-gray-500" />
                {post.tags.map((tag) => (
                  <motion.span
                    key={tag}
                    whileHover={{ scale: 1.1 }}
                    className="px-4 py-2 bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-700 rounded-full text-sm border border-emerald-200 cursor-pointer hover:shadow-md transition-shadow"
                  >
                    #{tag}
                  </motion.span>
                ))}
              </div>
            </motion.div>

            {/* Author Bio */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mt-12 p-6 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-xl border border-emerald-200"
            >
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center text-white text-2xl flex-shrink-0">
                  {post.author.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h3 className="text-xl mb-1">About {post.author.name}</h3>
                  <p className="text-gray-600 mb-2">{post.author.title}</p>
                  <p className="text-gray-700">{post.author.bio}</p>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.article>

        {/* Related Posts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <div className="flex items-center gap-2 mb-8">
            <TrendingUp className="w-6 h-6 text-emerald-600" />
            <h3 className="text-3xl bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Related Articles</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedPosts.map((relatedPost, index) => (
              <motion.div
                key={relatedPost.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.15)" }}
                className="bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer group border border-gray-200"
              >
                <div className="relative overflow-hidden h-40">
                  <motion.img
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                    src={relatedPost.image}
                    alt={relatedPost.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                </div>
                <div className="p-4">
                  <span className="text-xs px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full">
                    {relatedPost.category}
                  </span>
                  <h4 className="text-lg mt-3 mb-2 group-hover:text-emerald-600 transition-colors">{relatedPost.title}</h4>
                  <p className="text-sm text-gray-600">{relatedPost.readTime} read</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}