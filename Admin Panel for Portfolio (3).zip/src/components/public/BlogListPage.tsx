import { useState } from 'react';
import { Search, Calendar, Eye, Clock, ArrowRight, TrendingUp, Filter } from 'lucide-react';
import { motion } from 'framer-motion';

interface BlogListPageProps {
  onViewPost: (postId: string) => void;
}

export function BlogListPage({ onViewPost }: BlogListPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    'All',
    'ERP Development',
    'SAP Development',
    'Integration',
    'Performance',
    'Best Practices',
    'Tutorial',
  ];

  const blogPosts = [
    {
      id: '1',
      title: 'Understanding SAP ABAP Development Best Practices',
      excerpt: 'A comprehensive guide to writing clean and maintainable ABAP code in SAP development. Learn about naming conventions, modularization, and performance optimization.',
      category: 'SAP Development',
      tags: ['SAP', 'ABAP', 'Best Practices'],
      date: '2025-12-02',
      readTime: '8 min',
      views: 1243,
      image: 'https://images.unsplash.com/photo-1603351130949-476794ec3dff?w=800&h=400&fit=crop',
      featured: true,
    },
    {
      id: '2',
      title: 'Integrating ERP Systems with Modern Web Technologies',
      excerpt: 'Learn how to bridge traditional ERP systems with modern web frameworks and APIs. Explore REST APIs, webhooks, and real-time data synchronization.',
      category: 'Integration',
      tags: ['ERP', 'Web Dev', 'APIs'],
      date: '2025-11-28',
      readTime: '10 min',
      views: 892,
      image: 'https://images.unsplash.com/photo-1646153114001-495dfb56506d?w=800&h=400&fit=crop',
      featured: true,
    },
    {
      id: '3',
      title: 'Custom Function Modules in SAP: A Complete Guide',
      excerpt: 'Everything you need to know about creating and managing custom function modules in SAP. From basics to advanced patterns and error handling.',
      category: 'SAP Development',
      tags: ['SAP', 'Function Modules', 'Tutorial'],
      date: '2025-11-20',
      readTime: '12 min',
      views: 654,
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=400&fit=crop',
      featured: false,
    },
    {
      id: '4',
      title: 'Optimizing Performance in Large ERP Implementations',
      excerpt: 'Strategies and techniques for improving performance in enterprise-scale ERP systems. Database optimization, query tuning, and caching strategies.',
      category: 'Performance',
      tags: ['ERP', 'Optimization', 'Performance'],
      date: '2025-11-15',
      readTime: '15 min',
      views: 1089,
      image: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=800&h=400&fit=crop',
      featured: false,
    },
    {
      id: '5',
      title: 'Building Custom Reports in SAP with ALV',
      excerpt: 'Master the art of creating professional reports using ALV in SAP ABAP. Learn about ALV Grid, ALV Tree, and interactive report design.',
      category: 'Tutorial',
      tags: ['SAP', 'ALV', 'Reports'],
      date: '2025-11-10',
      readTime: '9 min',
      views: 789,
      image: 'https://images.unsplash.com/photo-1719400471588-575b23e27bd7?w=800&h=400&fit=crop',
      featured: false,
    },
    {
      id: '6',
      title: 'Error Handling Best Practices in ERP Development',
      excerpt: 'Implement robust error handling mechanisms in your ERP applications. Exception classes, logging, and user-friendly error messages.',
      category: 'Best Practices',
      tags: ['ERP', 'Error Handling', 'Development'],
      date: '2025-11-05',
      readTime: '7 min',
      views: 543,
      image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&h=400&fit=crop',
      featured: false,
    },
  ];

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredPosts = blogPosts.filter(post => post.featured);
  const regularPosts = filteredPosts.filter(post => !post.featured);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="py-12 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl mb-4 bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Blog</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Technical articles, tutorials, and insights about ERP development, SAP, and enterprise integrations
          </p>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-12"
        >
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="w-5 h-5 absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                />
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2"
              >
                <Filter className="w-5 h-5" />
                Search
              </motion.button>
            </div>

            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm text-gray-600">Filter by category:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <motion.button
                  key={category}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedCategory(category.toLowerCase())}
                  className={`px-4 py-2 rounded-lg transition-all ${
                    selectedCategory === category.toLowerCase()
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </motion.button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Featured Posts */}
        {featuredPosts.length > 0 && selectedCategory === 'all' && !searchQuery && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mb-12"
          >
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="w-6 h-6 text-emerald-600" />
              <h2 className="text-2xl bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Featured Articles</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {featuredPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  whileHover={{ y: -10, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.15)" }}
                  className="bg-white rounded-2xl shadow-lg overflow-hidden cursor-pointer group border border-gray-200"
                  onClick={() => onViewPost(post.id)}
                >
                  <div className="relative overflow-hidden h-64">
                    <motion.img
                      whileHover={{ scale: 1.1 }}
                      transition={{ duration: 0.6 }}
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="px-4 py-1.5 bg-yellow-400 text-gray-900 rounded-full text-sm shadow-lg">
                        ⭐ Featured
                      </span>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <span className="text-xs px-3 py-1 bg-emerald-500/90 backdrop-blur-sm text-white rounded-full">
                        {post.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-2xl mb-3 group-hover:text-emerald-600 transition-colors">{post.title}</h3>
                    <p className="text-gray-600 mb-4">{post.excerpt}</p>
                    
                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{post.readTime}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        <span>{post.views}</span>
                      </div>
                    </div>

                    <motion.div
                      whileHover={{ x: 5 }}
                      className="flex items-center gap-2 text-emerald-600"
                    >
                      <span>Read Article</span>
                      <ArrowRight className="w-4 h-4" />
                    </motion.div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* All Posts */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <h2 className="text-2xl mb-6 text-gray-900">All Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {regularPosts.map((post) => (
              <motion.div
                key={post.id}
                variants={itemVariants}
                whileHover={{ y: -10, boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1)" }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden cursor-pointer group border border-gray-200"
                onClick={() => onViewPost(post.id)}
              >
                <div className="relative overflow-hidden h-48">
                  <motion.img
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-3 left-3">
                    <span className="text-xs px-3 py-1 bg-white/90 backdrop-blur-sm text-gray-900 rounded-full">
                      {post.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl mb-3 group-hover:text-emerald-600 transition-colors line-clamp-2">{post.title}</h3>
                  <p className="text-gray-600 mb-4 line-clamp-2">{post.excerpt}</p>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                    <div className="flex items-center gap-1 text-gray-500">
                      <Eye className="w-4 h-4" />
                      <span className="text-sm">{post.views} views</span>
                    </div>
                    <motion.span
                      whileHover={{ x: 5 }}
                      className="text-emerald-600 flex items-center gap-1"
                    >
                      Read More
                      <ArrowRight className="w-4 h-4" />
                    </motion.span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {filteredPosts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12 bg-white rounded-2xl shadow-lg"
          >
            <p className="text-gray-500 text-lg">No articles found matching your criteria.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}