
  # Admin Panel for Portfolio

  This is a code bundle for Admin Panel for Portfolio. The original project is available at https://www.figma.com/design/0MOPIH7J28kgN0kpHLMORQ/Admin-Panel-for-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  